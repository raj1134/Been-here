package pieces;

import main.GamePanel;

public class King extends Piece {

    public King(int color, int col, int row) {
        super(color, col, row);

        if (color == GamePanel.WHITE) {
            image = getImage("/res/pieces/wk.png");
        } else {
            image = getImage("/res/pieces/bk.png");
        }
    }

}
