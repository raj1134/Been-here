package pieces;

import main.GamePanel;

public class Bishop extends Piece {

    public Bishop(int color, int col, int row) {
        super(color, col, row);

        if (color == GamePanel.WHITE) {
            image = getImage("/res/pieces/wb.png");
        } else {
            image = getImage("/res/pieces/bb.png");
        }
    }

}
