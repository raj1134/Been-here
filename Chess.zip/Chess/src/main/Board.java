package main;

import java.awt.Color;
import java.awt.Graphics2D;

public class Board {
    final int MAX_COL = 8;
    final int MAX_ROW = 8;
    public static final int SQUARE_SIZE = 68;
    public static final int HALF_SQUARE_SIZE = SQUARE_SIZE / 2;
    public Color secondColor = new Color(184, 135, 98);

    public void draw(Graphics2D g2) {
        for (int i = 0; i < MAX_ROW; i++) {
            for (int j = 0; j < MAX_COL; j++) {
                if ((i + j) % 2 == 0) {
                    g2.setColor(Color.WHITE);
                } else {
                    g2.setColor(secondColor);
                }
                g2.fillRect(j * SQUARE_SIZE, i * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE);
            }
        }
    }
}
